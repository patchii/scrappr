from flask_website import app
app.run(debug=True)
