# bootstrap glyph icon
ICON_TYPE_GLYPH = 'glyph'
# font awesome glyph icon
ICON_TYPE_FONT_AWESOME = 'fa'
# image relative to Flask static folder
ICON_TYPE_IMAGE = 'image'
# external image
ICON_TYPE_IMAGE_URL = 'image-url'
