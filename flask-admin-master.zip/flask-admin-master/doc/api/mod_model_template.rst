``flask_admin.model.template``
==============================

.. automodule:: flask_admin.model.template

	.. autofunction:: macro
