``flask_admin.actions``
=======================

.. automodule:: flask_admin.actions

    .. autofunction:: action

    .. autoclass:: ActionsMixin
        :members:
