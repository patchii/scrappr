# This file gets imported as part of running dev_appserver.py
import sys
sys.path = ['lib'] + sys.path
